package com.example.arjunpatidar.myretrofit2;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by arjunpatidar on 20/02/18.
 */

public interface ApiInterface {

    @GET("getcalories.php")
    Call<List<Calorieslist>> getCaloriesInfo();
}
