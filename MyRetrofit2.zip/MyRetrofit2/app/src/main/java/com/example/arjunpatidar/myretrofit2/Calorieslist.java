package com.example.arjunpatidar.myretrofit2;

import com.google.gson.annotations.SerializedName;

/**
 * Created by arjunpatidar on 20/02/18.
 */

public class Calorieslist {

    @SerializedName("name")
    private  String Name;

    @SerializedName("calories")
    private  int Calories;

    @SerializedName("image_path")
    private  String Image_path;

    public String getName() {
        return Name;
    }

    public int getCalories() {
        return Calories;
    }

    public String getImage_path() {
        return Image_path;
    }
}
