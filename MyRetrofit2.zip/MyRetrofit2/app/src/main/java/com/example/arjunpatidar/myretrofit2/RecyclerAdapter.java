package com.example.arjunpatidar.myretrofit2;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

/**
 * Created by arjunpatidar on 20/02/18.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    private List<Calorieslist> calorieslists;
    private Context context;

    public RecyclerAdapter(List<Calorieslist> calorieslists)
    {
        this.calorieslists = calorieslists;
        this.context = context;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.Name.setText(calorieslists.get(position).getName());
        holder.Calories.setText("Calories"+ Integer.toString(calorieslists.get(position).getCalories()));


    }

    @Override
    public int getItemCount() {
        return calorieslists.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView Name,Calories;
        ImageView Img;

        public MyViewHolder(View itemView) {
            super(itemView);
            Name = (TextView) itemView.findViewById(R.id.name);
            Calories = (TextView) itemView.findViewById(R.id.calories);
            Img = (ImageView) itemView.findViewById(R.id.image);

        }
    }
}